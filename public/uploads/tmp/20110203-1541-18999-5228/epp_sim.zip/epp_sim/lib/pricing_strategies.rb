require 'java'
require 'epp_sim'

module PricingStrategies
  
  class PricingStrategy
    
    def self.create_risk_neutral_utility(simulation_schema)
      @risk_neutral_utility = Java::jmarketsim.agentware.RiskAverseUtility.new(0, simulation_schema["kappa"], simulation_schema["mean dividend"], 1.0/(1.0+simulation_schema["interest rate"]))
    end
    
    def self.evaluate_with_risk_neutral_utility
      @risk_neutral_utility
    end
    
    attr_reader :buy_price_vector, :sell_price_vector, :shade
    attr_accessor :private_information, :parameters, :price_with_ra
    def initialize(shade, parameters, private_information)
    end
    def process_news(news)
      update_beliefs(news[0], news[1])
    end
    def get_prices(cash, shares, utility_function)
      if @price_with_ra == true
        calculate_prices(cash, shares, utility_function)
      else
        calculate_prices(cash, shares, PricingStrategy.evaluate_with_risk_neutral_utility)
      end
      @buy_price_vector.each {|x| x*((100.0-shade)/100.0)}
      @sell_price_vector.each {|x| x*((100.0+shade)/100.0)}
    end

    def calculate_prices(cash, shares, utility_function)
    end
    def to_s
      str = self.class.to_s
      str.slice!("PricingStrategies::")
      if @price_with_ra == true
        return "#{str}:RA:#{shade}"
      else
        return "#{str}:noRA:#{shade}"
      end
    end
  end

  class BayesianPricing < PricingStrategy
    def initialize(shade, parameters, private_information)
      @shade, @parameters, @private_information = shade, parameters, private_information
      @believed_news_variance = (@private_information.variance_low+@private_information.variance_high)/2.0
      @last_dividend = @parameters["mean dividend"]
      @shock_posterior_mean = 0.0
      @shock_variance = @parameters["signal shock std dev"]**2
      @shock_posterior_variance = @shock_variance
      @gamma = @shock_variance/(@shock_variance+@believed_news_variance)
      update_beliefs(@last_dividend, 0.0)
    end

    def update_beliefs(dividend, signal)
      if dividend != @last_dividend
        @shock_posterior_mean = 0.0
        @shock_posterior_variance = @shock_variance
        @last_dividend = dividend
      end
      @shock_posterior_mean = (1-@gamma)*@shock_posterior_mean+@gamma*signal
      @shock_posterior_variance = (@believed_news_variance*@shock_posterior_variance)/(@believed_news_variance+@shock_posterior_variance)
    end

    def calculate_prices(cash, shares, utility_function)
      value_vector = Array.new(@parameters["max shares per transaction"]).fill {|i| utility_function.cash_value(cash, shares+i, @last_dividend, @last_dividend/@parameters["interest rate"], @shock_posterior_mean, Math.sqrt(@shock_posterior_variance))}
      @buy_price_vector = Array.new(@parameters["max shares per transaction"]).fill {|i| utility_function.cash_value(cash, shares+i+1, @last_dividend, @last_dividend/@parameters["interest rate"], @shock_posterior_mean, Math.sqrt(@shock_posterior_variance))}
      for i in 0...@buy_price_vector.length
        @buy_price_vector[i] -= value_vector[i]
      end
      value_vector = Array.new(@parameters["max shares per transaction"]).fill {|i| utility_function.cash_value(cash, shares-i, @last_dividend, @last_dividend/@parameters["interest rate"], @shock_posterior_mean, Math.sqrt(@shock_posterior_variance))}
      @sell_price_vector = Array.new([[@parameters["max shares per transaction"], shares].min, 0].max).fill {|i| utility_function.cash_value(cash, shares-i-1, @last_dividend, @last_dividend/@parameters["interest rate"], @shock_posterior_mean, Math.sqrt(@shock_posterior_variance))}
      for i in 0...@sell_price_vector.length
        @sell_price_vector[i] = value_vector[i]-@sell_price_vector[i]
      end
    end
    
    def calculate_value(cash, shares, utility_function)
      utility_function.cash_value(cash, shares, @last_dividend, @last_dividend/@parameters["interest rate"], @shock_posterior_mean, Math.sqrt(@shock_posterior_variance))
    end
  end

  class AmbiguityAversePricing < PricingStrategy
    def initialize(shade, parameters, private_information)
      @shade, @parameters, @private_information = shade, parameters, private_information
      @last_dividend = @parameters["mean dividend"]
      @shock_posterior_mean = 0
      @shock_variance = @parameters["signal shock std dev"]**2
      @shock_posterior_variance = @shock_variance
      @gamma_low = @shock_variance/(@shock_variance+@private_information.variance_high)
      @gamma_high = @shock_variance/(@shock_variance+@private_information.variance_low)
      self.update_beliefs(@last_dividend, 0.0)
    end

    def update_beliefs(dividend, signal)
      if dividend != @last_dividend
        @shock_posterior_mean = 0
        @shock_posterior_variance = @shock_variance
        @last_dividend = dividend
      end

      @shock_posterior_mean_low = (1-@gamma_low)*@shock_posterior_mean+@gamma_low*signal;
      @shock_posterior_variance_low = (@private_information.variance_high*@shock_posterior_variance)/(@private_information.variance_high+@shock_posterior_variance)
      @shock_posterior_mean_high = (1-@gamma_high)*@shock_posterior_mean+@gamma_high*signal;
      @shock_posterior_variance_high = (@private_information.variance_low*@shock_posterior_variance)/(@private_information.variance_low+@shock_posterior_variance)
    end

    def establish_values(cash, shares, utility_function)
      value_low = utility_function.cash_value(cash, shares, @last_dividend, @last_dividend/@parameters["interest rate"], @shock_posterior_mean_low, Math.sqrt(@shock_posterior_variance_low))
      value_high = utility_function.cash_value(cash, shares, @last_dividend, @last_dividend/@parameters["interest rate"], @shock_posterior_mean_high, Math.sqrt(@shock_posterior_variance_high))
      if value_low < value_high
        @shock_posterior_mean = @shock_posterior_mean_low
        @shock_posterior_variance = @shock_posterior_variance_low
      else
        @shock_posterior_mean = @shock_posterior_mean_high
        @shock_posterior_variance = @shock_posterior_variance_high
      end
    end
    
    def calculate_prices(cash, shares, utility_function)
      establish_values(cash, shares, utility_function)
      value_vector = Array.new(@parameters["max shares per transaction"]).fill {|i| utility_function.cash_value(cash, shares+i, @last_dividend, @last_dividend/@parameters["interest rate"], @shock_posterior_mean, Math.sqrt(@shock_posterior_variance))}
      @buy_price_vector = Array.new(@parameters["max shares per transaction"]).fill {|i| utility_function.cash_value(cash, shares+i+1, @last_dividend, @last_dividend/@parameters["interest rate"], @shock_posterior_mean, Math.sqrt(@shock_posterior_variance))}
      for i in 0...@buy_price_vector.length
        @buy_price_vector[i] -= value_vector[i]
      end
      value_vector = Array.new(@parameters["max shares per transaction"]).fill {|i| utility_function.cash_value(cash, shares-i, @last_dividend, @last_dividend/@parameters["interest rate"], @shock_posterior_mean, Math.sqrt(@shock_posterior_variance))}
      @sell_price_vector = Array.new([[@parameters["max shares per transaction"], shares].min, 0].max).fill {|i| utility_function.cash_value(cash, shares-i-1, @last_dividend, @last_dividend/@parameters["interest rate"], @shock_posterior_mean, Math.sqrt(@shock_posterior_variance))}
      for i in 0...@sell_price_vector.length
        @sell_price_vector[i] = value_vector[i]-@sell_price_vector[i]
      end
      @buy_price_vector.each {|x| x-(@gamma_high-@gamma_low)*Math.sqrt(@shock_variance)/(@parameters["interest rate"]*Math.sqrt(2*Math::PI*@gamma_low))}
      @sell_price_vector.each {|x| x-(@gamma_high-@gamma_low)*Math.sqrt(@shock_variance)/(@parameters["interest rate"]*Math.sqrt(2*Math::PI*@gamma_low))}
    end
  
    def calculate_value(cash, shares, utility_function)
      establish_values(cash, shares, utility_function)
      utility_function.cash_value(cash, shares, @last_dividend, @last_dividend/@parameters["interest rate"], @shock_posterior_mean, Math.sqrt(@shock_posterior_variance))-shares*(@gamma_high-@gamma_low)*Math.sqrt(@shock_variance)/(@parameters["interest rate"]*Math.sqrt(2*Math::PI*@gamma_low))
    end
  end
end